/** Automatically generated file. DO NOT MODIFY */
package com.cookandroid.baseapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}